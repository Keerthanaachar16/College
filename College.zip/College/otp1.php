<?php
require __DIR__ . '/vendor/autoload.php'; // Path to Twilio PHP library

//use Twilio\Rest\Client;

// Twilio credentials
$account_sid = 'AC98f9cb9f5e37be2ab0c38645595f011a';
$auth_token = 'bedac0f354236cfb46c4955a683ad385';
$twilio_number = '9844043717';

// Initialize Twilio client
$client = new Client($account_sid, $auth_token);

// Generate random OTP
$otp = mt_rand(100000, 999999);

// Send OTP via SMS
$mobile_number = $_POST['mobile'];
$message = "Your OTP is: $otp";

try {
    $client->messages->create(
        $mobile_number,
        [
            'from' => $twilio_number,
            'body' => $message
        ]
    );
    echo "OTP sent successfully to $mobile_number";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
