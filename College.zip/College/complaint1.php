
<html>
<head>
<meta charset="UTF-8">
<Title>Complaints</title>
<link rel="stylesheet" href="ssty.css">
<link rel="stylesheet" href="style8.css">
<link rel="stylesheet" href="style10.css">
</head>
<body >

<div class="box">
<center>
<FORM  action="complaint2.php" method="POST">
<table border=0 align="center"  > 
<tr align="left">
<th bgcolor=>SID:</th>
<th>
<?php
session_start();
$sid=$_SESSION['username'];
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from student where sid='".$sid."'");
?>
<select name="sid" class="input-field" style="width:400px;height:30px;"required>
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['sid'];?></option>
<?php
}
?>
</select>

</th>
</tr>


<tr align="left">
<th>Date:</th>
<th>
<input type="text" id="date" name="date" style="width:300px;height:30px;" class="input-field"   readonly>
<script>
	document.getElementById("date").value=new Date().toLocaleDateString();
</script>
</th>
</tr>
<tr align="left">
<th>Subject:</th>
<th>
<input type="text" name="sub" style="width:400px;height:20px;"required>
</th>
</tr>
<tr align="left">
<th>Complaint Detailes:</th>
<th>
<textarea type="text" name="comdel"  class="textarea-field" placeholder="Complaint" required>
</textarea>

</th>
</tr>

</table><br><br>
<right><input type="submit" value="Submit" style="height=40px;width=400px;"></right>
</center>
</body>

<h1 style="text-align:left;"><a href="viewreply.html">ViewReply</a></h1>

<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background=:#34495e;
	background-image:url("https://t3.ftcdn.net/jpg/02/72/51/76/360_F_272517619_f9gT1LAtNPaEUXDdxSG25zaY8Ll2XI32.webp");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
</style>

</html>













