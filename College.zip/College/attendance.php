<?php
$tid=$_POST['tid'];
$sid=$_POST['sid'];
$date=$_POST['date'];
$status=$_POST['status'];

@$cn=new mysqli('localhost','root','','pro');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}

	$qry="insert into addattendance(tid,sid,date,status) values('".$tid."','".$sid."','".$date."','".$status."')";
	$rslt=$cn->query($qry);
	if($rslt)
	{
		echo "<script> alert('Record Submitted Successfully'); </script>";
	
	}



$cn->close();
?>
<br><br><h1><center><a style="text-decoration:none"  href="sidenav1.html">Back</a></center></h1>










