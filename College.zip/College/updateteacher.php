<?php
error_reporting();
@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}

$tid=$_GET['tid'];
$fname=$_GET['fname'];
$lname=$_GET['lname'];
$email=$_GET['email'];
$phone=$_GET['phone'];
$address=$_GET['address'];
$state=$_GET['state'];

?>
<html>
<body>
<link rel="stylesheet" href="style13.css">
<form action="" method="GET">
<table border="0"  align="center" cellspacing="20">
<tr>
<td>TeacherId</td>
<td><input type="text" value="<?php echo"$tid"?>"name="tid" required</td>
</tr>

<tr>
<td>Fname</td>
<td><input type="text" value="<?php echo"$fname"?>"name="fname" required></td>
</tr>
<tr>
<td>Lname</td>
<td><input type="text" value="<?php echo"$lname"?>"name="lname" required></td>
</tr>
<tr>
<td>Email</td>
<td><input type="email" value="<?php echo"$email"?>"name="email" required></td>
</tr>
<tr>
<td>Phone</td>
<td><input type="number"  min=1000000000 max=9999999999 value="<?php echo"$phone"?>"name="phone" required></td>
</tr>
<tr>
<td>Address</td>
<td><input type="text"  value="<?php echo"$address"?>"name="address" required></td >
</tr>
<tr>
<td>State</td>
<td><input type="text" value="<?php echo"$state"?>"name="state" required></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Update"></a></td></tr>
</form>
</table>
</body>
<style>
body
{
	background-image:url("https://i.ytimg.com/vi/WLgFGgNl8m8/maxresdefault.jpg");
	background-repeat:no repeat;
	background-size:cover;
	background-attachment:fixed;
}
</style>
</html>
<?php
@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}
if(isset($_GET['submit']))
{


	$tid=$_GET['tid'];
	$fname=$_GET['fname'];
	$lname=$_GET['lname'];
	$email=$_GET['email'];
	$phone=$_GET['phone'];
	$address=$_GET['address'];
	$state=$_GET['state'];
	$query="update teacher set  fname='$fname',lname='$lname',email='$email',phone='$phone',address='$address',state='$state' where tid='".$tid."'";
	$data=mysqli_query($cn,$query);
	if($data)
	{
		echo"<script>alert('record updated sucessfully')</script>";
	}
	else
	{
		echo"<script>alert('Failed to update')</script>";
	}
}

$cn->close();
?>
<br><br><a href="teacherview.php">BACK</a>



