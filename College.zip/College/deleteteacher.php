<?php
@$cn=new mysqli('localhost','root','','college');
if($cn->connect_error)
{
	echo"could not connect";
	exit;
}
$tid=$_GET['tid'];
$query="delete from teacher where tid='".$tid."'";
$data=mysqli_query($cn,$query);
if($data)
{
	echo"Record deleted sucessfully";
}
$cn->close();
?>
<br><br><a href="teacherview.php">BACK</a>



