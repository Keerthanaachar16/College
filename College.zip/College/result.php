
<?php

if(isset($_POST['Search']));
{
	$sid=$_POST['sid'];
	@$cn=new mysqli('localhost','root','','college');
	if(mysqli_connect_errno())
	{
		echo"Could not connect";
		exit;
	}
	$query="Select * from marksupload where sid='".$sid."'";
	$rslt=$cn->query($query);
	if($rslt->num_rows!=0)

	{
	echo "<table border='1'>
	<tr>
	<th>Student id</th>
	<th>Course</th>
	<th>ExamName</th>
	<th>MarksObtained</th>
	<th>Totalmarks</th>
	<th>TeacherId</th>
	<th>DateofExam</th>
	</tr>";
	
	
		
		while($row=$rslt->fetch_assoc())
		{
			echo"<tr>";
			echo "<td>".$row['sid']."</td>";
			echo "<td>".$row['course']."</td>";
			echo "<td>".$row['examname']."</td>";
			echo "<td>".$row['marksobtained']."</td>";
			echo "<td>".$row['totalmarks']."</td>";
			echo "<td>".$row['tid']."</td>";
			echo "<td>".$row['dateofexam']."</td>";
			echo"</tr>";
		}
	}
	else
	{
		echo" Results Could not Found..";
	}
echo"</table>";
}
?>
