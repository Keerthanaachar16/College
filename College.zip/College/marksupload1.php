<?php

$sid=$_POST['sid'];
$course=$_POST['course'];
$examname=$_POST['examname'];
$marksobtained=$_POST['marksobtained'];
$totalmarks=$_POST['totalmarks'];
$tid=$_POST['tid'];
$dateofexam=$_POST['dateofexam'];
@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}

	$qry="insert into marksupload(sid,course,examname,marksobtained,totalmarks,tid,dateofexam) values('".$sid."','".$course."','".$examname."',".$marksobtained.",".$totalmarks.",'".$tid."','".$dateofexam."')";
	$rslt=$cn->query($qry);
	if($rslt)
	{
		echo "<script> alert('Marks Uploaded Successfully'); </script>";
	
	}



$cn->close();
?>

<br><br><h1><center><a style="text-decoration:none"  href="sidenav1.html">Back</a></center></h1>










