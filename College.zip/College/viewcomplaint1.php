<html>
<head>
<title>Complaint</title>
</head>
<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background=:#34495e;
	background-image:url("https://th.bing.com/th/id/R.5f26895ab4ed7bd73ae34b03f1fc65df?rik=xPKqsM2b8L2oxA&riu=http%3a%2f%2fwww.techadv.com%2fsites%2fdefault%2ffiles%2fstyles%2fblog_header%2fpublic%2f2020-04%2fcomplaints.jpg.jpeg%3fitok%3d3DLBe1zX&ehk=%2fn3jASI2pyQI1Pw5NNlBJit05v325Fw5p4y97wFihV4%3d&risl=&pid=ImgRaw&r=0");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
table{
	border-collopse:collopse;
	box-shadow:0 5px 10px $clr-gray300;
	text-align:left;
	overflow:hidden;
	border-radius:12px;
	background-color:white;
}
th{
	padding:1rcm 2rcm;
	border-radius:7px;
	
	border:2px solid #2e003e;
	letter-spacing:0.1rcm;
	font-size:0.7rcm;
	font-weight:900;
}
tr{
	padding:1rcm 2rcm;
	border-radius:10px;
	
	border:2px solid #2e003e;
	letter-spacing:0.1rcm;
	font-size:0.7rcm;
	font-weight:700;
}
</style>


</html>
<?php
@$cn=new mysqli('localhost','root','','college');
if($cn->connect_error)
{
	echo"could not connect";
	exit;
}
$qry="select * from complaint";
$rslt=$cn->query($qry);
$nob=$rslt->num_rows;
echo"<table border='1' cellpadding='7' align=center style='font-size:20px;'>
<tr><th>StudentId</th><th>Date</th><th>Subject</th><th>ComplaintDel</th></tr>";
for($i=0;$i<$nob;$i++)
{
	$r=$rslt->fetch_assoc();
	echo"<tr><th>".$r['sid']."</th><th>".$r['date']."</th><th>".$r['sub']."</th><th>".$r['comdel']."</th></tr>";

}
echo"</table>";

$cn->close();
?>
<br><br><h1><center><a style="text-decoration:none"  href="reply1.php">Reply</a></center></h1>


