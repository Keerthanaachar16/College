<?php

$sid=$_POST['sid'];
$date=$_POST['date'];
$sub=$_POST['sub'];
$comdel=$_POST['comdel'];

@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}

	$qry="insert into complaint(sid,date,sub,comdel) values('".$sid."','".$date."','".$sub."','".$comdel."')";
	$rslt=$cn->query($qry);
	if($rslt)
	{
		echo "<script> alert('Complaint submitted Successfully'); </script>";
		
	}



$cn->close();
?>
<br><br><a href="sidenav3.html">BACK</a>










