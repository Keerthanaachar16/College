<html>
<head>
<meta charset="UTF-8">
<Title>reply</title>
<link rel="stylesheet" href="style10.css">
</head>
<body >

<div class="box">
<center>
<FORM  action="reply21.php" method="POST">
<table border=0 align="center" bgcolor="lightblue">
<tr align="left">
<th>StudentId</th>
<th>
<?php
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from complaint");
?>
<select name="studid" class="input-field">
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['sid'];?></option>
<?php
}
?>
</select>

</th>
</tr> 
<tr align="left">
<th>TeacherId</th>
<th>
<?php
session_start();
$tid=$_SESSION['username'];
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from teacher where tid='".$tid."'");
?>
<select name="tid" class="input-field">
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['tid'];?></option>
<?php
}
?>
</select>

</th>
</tr> 



<tr align="left">
<th>Reply</th>
<th>
<textarea type="text" name="reply" class="textarea-field" placeholder="Reply...">
</textarea>
</th>

</table><br><br>
<right><input type="submit" value="Reply" style="height=40px;width=400px;"></right>
</center>
</body>
<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background=:#34495e;
	background-image:url("https://paymentcloudinc.com/blog/wp-content/uploads/2022/07/accountant-using-payroll-software.jpg");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
</style>
</html>












