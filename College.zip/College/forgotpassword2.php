<html>
<body>
<link rel="stylesheet" type="text/css" href="style4.css">
<form action="" method="POST">
<h2>Forgot Password</h2>
<label>Username</label>
<input type="text" name="un" required><br/><br/>
<label>New password </label>
<input type="password" name="npwd"  maxlength="9" pattern="^Stud[A-Za-z][0-9]*" required><br/><br/>
<label>Confirm Password </label>
<input type="password" name="cpwd" required><br/><br/>

<input type="submit" name="submit" value="Update">
</form>
<a href="sidenav.html">BACK</a>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
	$un=$_POST['un'];
	$npwd=$_POST['npwd'];
	$cpwd=$_POST['cpwd'];
	echo"<form target='self'>";
	echo"<font size='6'>";
	@$cn=new mysqli('localhost','root','','college');
	if($cn->connect_error)
	{
		echo"Could not connect";
		exit;
	}
	$qry="select * from studentlogin where username='".$un."'"; 
	$rslt=$cn->query($qry);
	if($rslt->num_rows!=0)
	{
		$uqry="update studentlogin set password='".$npwd."'";
		$rslt=$cn->query($uqry);
		if($rslt)
		{
			echo"<script>alert('Records Updated successfully');</script>";
			echo"<script>window.location.href='studentlogin.php';</script>";
		}
		
	}

else
{
	echo"<script>alert('Records not found');</script>";
}
if($npwd!==$cpwd)
		{
			header("Location:forgotpassword2.php?error=The confirmation password doesn't match");
				exit();
			
		}

$cn->close();
}

?>








