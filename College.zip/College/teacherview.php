<?php
$con=mysqli_connect('localhost','root','','college');
$result=$con->query("Select  * from teacher");
echo"<table   border='1' align=center >
<table style=background-color:#3 align=center  border='1'>

<tr>
<th>Teacherid</th>
<th>Fname</th>
<th>Lname</th>
<th>Email</th>
<th>Phone</th>
<th>Address</th>
<th>State</th>
<th>Username</th>
<th>Password</th>
<th colspan=2 align=center>Operations</th>
</tr>";

while($r=$result->fetch_assoc())
{
	echo"<tr>
	<td>".$r['tid']."</td>
	<td>".$r['fname']."</td>
	<td>".$r['lname']."</td>
	<td>".$r['email']."</td>
	<td>".$r['phone']."</td>
	<td>".$r['address']."</td>
	<td>".$r['state']."</td>
	<td>".$r['username']."</td>
	<td>".$r['password']."</td>
	<td><a href='updateteacher.php?tid=$r[tid]&fname=$r[fname]&lname=$r[lname]&email=$r[email]&phone=$r[phone]&address=$r[address]&state=$r[state]'><input type='submit' value='Update' ></a></td>
	<td><a href='deleteteacher.php?tid=$r[tid]'>delete</td>
	</tr>";
	
}


$con->close();


?>
<html>
<head>
<title>Teacherview</title>
<style>
<style>
*{
	margin:0;
	padding:0;
	font-family:arial;
	box-sizing:border-box;
	
}
body{
	height:20vh;
	display:grid;
	place-items:center;
}
table{
	width:200px;
	box-shadow:-1px 12px 12px -6px rgba(0,0,0,0.5);
	align:center;
	
}
table,tr,td,th{
	padding:10px;
	border:1px solid lightgray;
	border-collapse:collapse;
	text-align:center;
}
td{
	font-size:18px;
}
th{
	background-color:lightblue;
	color:white;
	
}
tr:nth-child(odd){
	background-color:white;
}
tr:nth-child(odd):hover{
	background-color:lightblue;
	color:white;
	transform:scale(1);
	transition:transform 300ms ease-in;
}
tr:nth-child(even){
	background-color:lightgray;
}
tr:nth-child(even):hover{
	background-color:gray;
	color:white;
	transform:scale(1);
	transition:transform 300ms ease-in;
}
body
{
	background-image:url("https://wallpapercave.com/wp/wp4618114.jpg");
	background-repeat:no repeat;
	background-size:cover;
}
</style>
<style>

a{
	background-color:lightblue;
	color:white;
	padding:5px;
	color:white;
	text-decoration:none;
	border-radius:10px;
	place-items:left;
}
a:hover{
	background:gray;
	color:white;
	
}
</style>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
<div class="logo">
<p align="left" style="color:white">Teacher Details</p>
</div>
<nav>
<ul>
<a href="sidenav2.html">Back</a>
</ul>
</nav>

<a href="addteacher.html">AddTeacher</a>
</body>
</head>
</html>





