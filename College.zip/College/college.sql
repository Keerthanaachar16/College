-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2025 at 10:49 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`username`, `password`) VALUES
('Admin ', 'Admin292');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `sid` varchar(10) NOT NULL,
  `tid` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`sid`, `tid`, `date`, `status`) VALUES
('1', '1', '2024-04-13', 'present'),
('1', '1', '2024-04-19', 'present'),
('2', '1', '2024-04-17', 'present'),
('6', '3', '', 'present'),
('6', '3', '', 'present'),
('6', '3', '', 'present'),
('6', '3', '', 'present'),
('3', '3', '', 'present'),
('3', '3', '', 'present'),
('2', '3', '4/19/2024', 'present');

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `sid` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `comdel` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`sid`, `date`, `sub`, `comdel`) VALUES
('1', '2024-04-12', 'dfhyui', 'dffdyfryh\r\ngfjgjjhyfkjfk'),
('1', '2024-04-12', 'Subject', 'abcderhydt'),
('1', '2024-04-14', 'abcd', 'ggfnbdjnndfhbbhfg\r\n'),
('0', '', 'abcd', 'ghhtctdmmmmmm'),
('0', '', 'abcd', 'ghhtctdmmmmmm'),
('0', '', 'abcd', 'ghhtctdmmmmmm'),
('0', '', 'abcd', 'ghhtctdmmmmmm'),
('0', '', 'abcd', 'ghhtctdmmmmmm'),
('0', '4/19/2024', 'abcd', 'vgddsdsszxx'),
('', '4/19/2024', 'abcd', 'vgddsdsszxx'),
('', '4/19/2024', 'abcd', 'vgddsdsszxx'),
('', '4/19/2024', 'dfgdhgv', 'ftrtdtrgt'),
('', '4/19/2024', 'dfgdhgv', 'ftrtdtrgt'),
('6', '4/19/2024', 'dfhyui', 'vdgfvvbvxzfvdbd');

-- --------------------------------------------------------

--
-- Table structure for table `marksupload`
--

CREATE TABLE `marksupload` (
  `sid` varchar(10) NOT NULL,
  `course` varchar(10) NOT NULL,
  `examname` varchar(10) NOT NULL,
  `marksobtained` int(20) NOT NULL,
  `totalmarks` int(20) NOT NULL,
  `tid` varchar(10) NOT NULL,
  `dateofexam` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marksupload`
--

INSERT INTO `marksupload` (`sid`, `course`, `examname`, `marksobtained`, `totalmarks`, `tid`, `dateofexam`) VALUES
('2', 'bca', '1st', 90, 100, '1', '2024-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `reply`
--

CREATE TABLE `reply` (
  `studid` int(10) NOT NULL,
  `adminid` varchar(10) NOT NULL,
  `tid` int(10) NOT NULL,
  `reply` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reply`
--

INSERT INTO `reply` (`studid`, `adminid`, `tid`, `reply`) VALUES
(1, 'Admin292', 0, 'reply');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` int(10) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `state` varchar(10) NOT NULL,
  `course` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `fname`, `lname`, `email`, `phone`, `address`, `state`, `course`, `username`, `password`) VALUES
(1, 'Keerthana', 'K', 'kachar292916@gmail.com', 9747483647, 'Kundapura', 'Karnataka', 'bca', 'Student1', 'Student1'),
(2, 'Sushmitha', 'R', 'sush123@gmail.com', 9867453219, 'Mangalore', 'Karnataka', 'bca', 'Student2', 'Stuident2'),
(3, 'Rashmitha', 'Karanth', 'rash@gmail.com', 9657432167, 'Mangalore', 'Karnataka', 'bca', 'Student3', 'S3'),
(6, 'Rashmitha', 'Poojary', 'rash@gmail.com', 8756942685, 'Kundapura', 'Karnataka', 'bcom', 'Student4', 'Studc');

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE `studentlogin` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `tid` int(10) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `state` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tid`, `fname`, `lname`, `email`, `phone`, `address`, `state`, `username`, `password`) VALUES
(1, 'Kavya S', 'Poojary', 'ka5678@gmail.com', 9147483647, 'Kundapura', 'Karnataka', 'Teacher1', 'Teacher1'),
(3, 'Kavya', 'K Chandan', 'Kavya292916@gmail.com', 9658745688, 'Mangalore', 'Karnataka', 'Teacher2', 'Teacha');

-- --------------------------------------------------------

--
-- Table structure for table `teacherlogin`
--

CREATE TABLE `teacherlogin` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `tid` varchar(10) NOT NULL,
  `course` varchar(10) NOT NULL,
  `timings` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`tid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `tid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
