
<?php

if(isset($_POST['ViewReply']));
{
	$studid=$_POST['studid'];
	@$cn=new mysqli('localhost','root','','college');
	if(mysqli_connect_errno())
	{
		echo"Could not connect";
		exit;
	}
	$query="Select * from reply where studid='".$studid."'";
	$rslt=$cn->query($query);
	if($rslt->num_rows!=0)

	{
	echo "<table border='1'>
	<tr>
	<th>Student id</th>
	<th>Admin id</th>
	<th>Teacher id</th>
	<th>Reply</th>
	</tr>";
	
	
		
		while($row=$rslt->fetch_assoc())
		{
			echo"<tr>";
			echo "<td>".$row['studid']."</td>";
			echo "<td>".$row['adminid']."</td>";
			echo "<td>".$row['tid']."</td>";
			echo "<td>".$row['reply']."</td>";
			echo"</tr>";
		}
	}
	else
	{
		echo" No records Found";
	}
echo"</table>";
}
?>
