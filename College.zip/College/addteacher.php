<?php
$fa=$_POST['fa'];
$la=$_POST['la'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$state=$_POST['state'];
$un=$_POST['username'];
$pw=$_POST['password'];
@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}


$qry="select * from teacher where username='".$un."'";
$rslt=$cn->query($qry);
if($rslt->num_rows!=0)
{
	
	echo "<script>alert('Already added');</script>";
	echo"<script>windows.location.href='sidenav2.html';</script>";
	exit;
}
else
{
	$qry="insert into teacher(fname,lname,email,phone,address,state,username,password) values('".$fa."','".$la."','".$email."',".$phone.",'".$address."','".$state."','".$un."','".$pw."')";
	$rslt=$cn->query($qry);
	if($rslt)
	{
		echo "<script> alert('Teacher Added Successfully'); </script>";
		echo "<script>windows.location.href='sidenav2.html';</script>";
	}
}


$cn->close();
?>
<br><br><h1><a style="text-decoration:none" href="teacherview.php">BACK</a></h1>








