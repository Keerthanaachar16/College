<html>
<head>
<meta charset="UTF-8">
<Title>Attendance</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="style10.css">
</head>
<body >

<div class="box">
<div class="dropdown">
<div class="select">

<center>
<FORM  action="addattendance1.php" method="POST">
<table border=0 align="center">


<tr align="left">

<th>StudentId</th>
<th>
<?php
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from student");
?>
<select name="sid" class="input-field">
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['sid'];?></option>
<?php
}
?>
</select>

</th>
</tr><br><br>
<tr align="left">
<th>TeacherId</th>
<th>
<?php
session_start();
$tid=$_SESSION['username'];
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from teacher where tid='".$tid."'");
?>
<select name="tid"class="input-field">
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['tid'];?></option>
<?php
}
?>
</select>

</th>
</tr><br><br>
</div>
</div>
<tr align="left">
<th>Date</th>
<th>
<input type="text" id="date" name="date" style="width:300px;height:30px;" class="input-field"   readonly>
<script>
	document.getElementById("date").value=new Date().toLocaleDateString();
</script>
<script>
	var currentDate=new Date();
	var formattedDate=currentDate.toDateString();
	document.getElementById("currentDate").innerText=formattedDate;
	
	
</script>
</th>
</tr><br><br>
<tr align="left">
<th>status</th>
<th>
<select name="status" class="input-field">
	<option value="present">Present</option>
	<option value="absent">Absent</option>
	
</select>
</th>
</tr><br>
</table><br><br>

<right><input type="submit" value="Submit" style="height=40px;width=400px;"></right>
</html>
<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background=:#34495e;
	background-image:url("https://media.istockphoto.com/id/538665734/photo/teacher-may-i-ask-something.jpg?s=612x612&w=0&k=20&c=6GxwT_R6g0fG_Yq1JI3dEQhm6-elK8x-78G2A3pFO0s=");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
</style>
</html>