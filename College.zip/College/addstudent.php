<?php
$fa=$_POST['fa'];
$la=$_POST['la'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$state=$_POST['state'];
$course=$_POST['course'];
$un=$_POST['username'];
$pw=$_POST['password'];
@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}


$qry="select * from student where username='".$un."'";
$rslt=$cn->query($qry);
if($rslt->num_rows!=0)
{
	
	echo "<script>alert('Already added');</script>";
	echo"<script>windows.location.href='sidenav2.html';</script>";
	exit;
}
else
{
	$qry="insert into student(fname,lname,email,phone,address,state,course,username,password) values('".$fa."','".$la."','".$email."',".$phone.",'".$address."','".$state."','".$course."','".$un."','".$pw."')";
	$rslt=$cn->query($qry);
	if($rslt)
	{
		echo "<script> alert('Student Added Successfully'); </script>";
		echo "<script>windows.location.href='sidenav2.html';</script>";
	}
}


$cn->close();
?>
<br><br><h1><a style="text-decoration:none" href="studentview.php">BACK</a></h1>










