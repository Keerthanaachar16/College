<?php
@$cn=new mysqli('localhost','root','','college');
if($cn->connect_error)
{
	echo"could not connect";
	exit;
}
$sid=$_GET['sid'];
$query="delete from student where sid='".$sid."'";
$data=mysqli_query($cn,$query);
if($data)
{
	echo"Record deleted sucessfully";
}
$cn->close();
?>
<br><br><a href="studentview.php">BACK</a>



