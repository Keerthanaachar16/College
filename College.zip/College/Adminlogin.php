<html>
<head>
<body>
<header>
<div class="logo">
<p>Admin Login</p>
</div>
<nav>
<ul>
<li><button><a href="teacherlogin.php">Teacher</a></button></li>
<li><button><a href="studentlogin.php">Student</a></button></li>
<li><button><a href="index.html">Back</a></button></li>

</ul>
</nav>
</header>
</div>
</body>
<body>
<link rel="stylesheet" href="style1.css">
<link rel="stylesheet" href="sty.css">
<div class="center">
<div class="header">Login</div>
<form action="" method="POST">
username<input type="text" name="username" required><br><br>
password<input id="pw" type="password" name="password" required><br><br>
<input type="submit" name="submit" value="Login">
<a href="forgotpassword.php">Forgot password?</a>
</div>
</form>
</div>

</html>
<?php
session_start();
$host="localhost";
$user="root";
$password="";
$db="college";
@$cn=mysqli_connect($host,$user,'','college');

if(isset($_POST['submit']))
{
	$un=$_POST['username'];
	$pw=$_POST['password'];
	$sql="select * from adminlogin where username='".$un."'AND password='".$pw."'";
	$data=mysqli_query($cn,$sql);
	$row=mysqli_fetch_assoc($data);
	$total=mysqli_num_rows($data);
	if($total==1)
	{
		$_SESSION['username']=$row['adminid'];
		$_SESSION['password']=$pw;
		echo"Logged in Successfully";
		header('location:sidenav2.html');
	}
	else
	{
		echo"<p><font color=red size='7pt'</p>Login Failed";
	}
}
?>

	