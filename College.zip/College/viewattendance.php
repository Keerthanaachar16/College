<html>
<head>
<title>ViewAttendance</title>
</head>
<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background=:#34495e;
	background-image:url("https://img.freepik.com/free-photo/back-school-concept-pink-background-with-copy-space_106006-521.jpg?size=626&ext=jpg");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
</style>
</html>


<?php

if(isset($_POST['ViewAttendance']));
{
	$sid=$_POST['sid'];
	@$cn=new mysqli('localhost','root','','college');
	if(mysqli_connect_errno())
	{
		echo"Could not connect";
		exit;
	}
	$query="Select * from attendance where sid='".$sid."'";
	$rslt=$cn->query($query);
	if($rslt->num_rows!=0)

	{
	echo "<table border='1'>
	<tr>
	<th>Teacher id</th>
	<th>Student id</th>
	<th>Date</th>
	<th>Status</th>
	</tr>";
	
	
		
		while($row=$rslt->fetch_assoc())
		{
			echo"<tr>";
			echo "<td>".$row['sid']."</td>";
			echo "<td>".$row['tid']."</td>";
			echo "<td>".$row['date']."</td>";
			echo "<td>".$row['status']."</td>";
			echo"</tr>";
		}
	}
	else
	{
		echo" No records Found";
	}
echo"</table>";
}
?>
