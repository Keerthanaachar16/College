<?php
$sid=$_POST['sid'];
$tid=$_POST['tid'];
$date=$_POST['date'];
$status=$_POST['status'];

@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}

	$qry="insert into attendance(sid,tid,date,status) values(".$sid.",".$tid.",'".$date."','".$status."')";
	$rslt=$cn->query($qry);
	if($rslt)
	{
		echo "<script> alert('Record Submitted Successfully'); </script>";
	
	}



$cn->close();
?>
<br><br><h1><center><a style="text-decoration:none"  href="sidenav1.html">Back</a></center></h1>










