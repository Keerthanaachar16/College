<html>
<head>
<meta charset="UTF-8">
<Title>Student</title>
<link rel="stylesheet" href="style10.css">
</head>
<body >

<div class="box">
<center>
<FORM  action="reply11.php" method="POST">
<table border=0 align="center" bgcolor="teal">
<tr align="left">
<th>StudentId</th>
<th>
<?php
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from complaint");
?>
<select name="studid" class="input-field">
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['sid'];?></option>
<?php
}
?>
</select>

</th>
</tr> 
<tr align="left">
<th>AdminId</th>
<th>
<?php
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from adminlogin");
?>
<select name="adminid" class="input-field">
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['password'];?></option>
<?php
}
?>
</select>

</th>
</tr> 



<tr align="left">
<th>Reply</th>
<th>
<textarea type="text" name="reply" class="textarea-field" placeholder="Reply...">
</textarea>
</th>

</table><br><br>
<right><input type="submit" value="Reply" style="height=40px;width=400px;"></right>
</center>
</body>
<style>
body
{
	background-image:url("https://images.pexels.com/photos/7112/woman-typing-writing-windows.jpg?cs=srgb&dl=pexels-startup-stock-photos-7112.jpg&fm=jpg");
	background-repeat:no repeat;
	background-size:cover;
	background-attachment:fixed;
}

</style>
</html>











