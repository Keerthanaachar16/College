<?php
$otp=mt_rand(100000,999999);
$_SESSION['otp']=$otp;
$phone=$_POST['phone']
$message="Your OTP is:$otp";
?>