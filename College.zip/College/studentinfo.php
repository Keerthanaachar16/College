
<?php

if(isset($_POST['Search']));
{
	$sid=$_POST['sid'];
	@$cn=new mysqli('localhost','root','','college');
	if(mysqli_connect_errno())
	{
		echo"Could not connect";
		exit;
	}
	$query="Select * from student where sid='".$sid."'";
	$rslt=$cn->query($query);
	if($rslt->num_rows!=0)

	{
	echo "<table border='1'>
	<tr>
	<th>Student id</th>
	<th>Fname</th>
	<th>Lname</th>
	<th>Email</th>
	<th>Phone</th>
	<th>Address</th>
	<th>State</th>
	<th>Course</th>
	<th>Username</th>
	<th>Password</th>
	</tr>";
	
	
		
		while($row=$rslt->fetch_assoc())
		{
			echo"<tr>";
			echo "<td>".$row['sid']."</td>";
			echo "<td>".$row['fname']."</td>";
			echo "<td>".$row['lname']."</td>";
			echo "<td>".$row['email']."</td>";
			echo "<td>".$row['phone']."</td>";
			echo "<td>".$row['address']."</td>";
			echo "<td>".$row['state']."</td>";
			echo "<td>".$row['course']."</td>";
			echo "<td>".$row['username']."</td>";
			echo "<td>".$row['password']."</td>";
			echo"</tr>";
		}
	}
	else
	{
		echo" No records Found";
	}
echo"</table>";
}
?>
<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background=:#34495e;
	background-image:url("https://img.freepik.com/free-vector/student-graduation-cap-using-computer-desk_1262-21421.jpg");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
</style>
