<html>
<head>
<title>Complaint</title>
</head>
<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background=:#34495e;
	background-image:url("https://th.bing.com/th/id/OIP.lnSPTJ2j6pwJR3c6rpBDlAAAAA?w=416&h=416&rs=1&pid=ImgDetMain");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
</style>
</html>

</html>
<?php
@$cn=new mysqli('localhost','root','','college');
if($cn->connect_error)
{
	echo"could not connect";
	exit;
}
$qry="select * from complaint";
$rslt=$cn->query($qry);
$nob=$rslt->num_rows;
echo"<table border='1' cellpadding='7' align=center style='font-size:20px;'>
<tr><th>StudentId</th><th>Date</th><th>Subject</th><th>ComplaintDel</th></tr>";
for($i=0;$i<$nob;$i++)
{
	$r=$rslt->fetch_assoc();
	echo"<tr><th>".$r['sid']."</th><th>".$r['date']."</th><th>".$r['sub']."</th><th>".$r['comdel']."</th></tr>";

}
echo"</table>";

$cn->close();
?>
<br><br><h1><center><a style="text-decoration:none"  href="reply2.php">Reply</a></center></h1>