<html>
<head>
<meta charset="UTF-8">
<Title>Marksupload</title>
<link rel="stylesheet" href="style10.css">
</head>
<body>

<div class="contact-box">
<center>


<FORM  action="marksupload1.php" method="POST">
<span style="color:violet;font-size:30px">Marks Upload</span></a>
<table border=0 align="center" bgcolor="">
<tr align="left">
<th bgcolor=''>StudentId</th>
<th>
<?php
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from student");
?>
<select name="sid" class="input-field" required>
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['sid'];?></option>
<?php
}
?>
</select>

</th>
</tr> 
<tr align="left">
<th bgcolor=''>Course</th>
<th>
<select name="course" class="input-field" required>
	<option value="bca">BCA</option>
	<option value="bcom">B.Com</option>
	<option value="bsc">B.Sc</option>
	<option value="ba">BA</option>
</select>
</th>
</tr><br>
<tr align="left">
<th bgcolor=''>Examname</th>
<th>
<select name="examname" class="input-field" required>
	<option value="1st">1st</option>
	<option value="2nd">2nd</option>
	
</select>
</th>
</tr><br>
<tr align="left">
<th bgcolor=''>MarksObtained</th>
<th>
<input type="number"   class="input-field" name="marksobtained" min=0 max=100 style="width:300px;height:30px;" placeholder="Enter marks" required>
</th>
</tr>
<tr align="left">
<th bgcolor=''>Totalmarks</th>
<th>
<select name="totalmarks" class="input-field">
	<option value="100">100</option>
</select>
</th>
</tr><br>
<tr align="left">
<th bgcolor=''>TeacherId</th>
<th>
<?php
session_start();
$tid=$_SESSION['username'];
$cn=mysqli_connect("localhost","root","","college");
$s=mysqli_query($cn,"select * from teacher where tid='".$tid."'");
?>
<select name="tid" class="input-field" required>
<?php
	while($r=mysqli_fetch_array($s))
	{
		?>
		<option><?php echo $r['tid'];?></option>
<?php
}
?>
</select>

</th>
</tr> 
<tr align="left">
<th bgcolor=''>DateofExam</th>
<th>

<input type="text" id="date" name="date" style="width:300px;height:30px;" class="input-field"   readonly>
<script>
	document.getElementById("date").value=new Date().toLocaleDateString();
</script>
</th>
</tr>

</table><br><br>
<right><input type="submit" value="Upload" style="height=40px;width=400px;"></right>
</center>
</body>
<style>
body
{
	background-image:url("https://cdn1.vectorstock.com/i/1000x1000/18/45/numbers-background-vector-1061845.jpg");
	background-repeat:no repeat;
	background-size:cover;
	background-attachment:fixed;
}

</style>
</html>









