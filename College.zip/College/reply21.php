<?php

$studid=$_POST['studid'];
$tid=$_POST['tid'];
$reply=$_POST['reply'];

@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}

	$qry="insert into reply(studid,adminid,reply) values('".$studid."','".$tid."','".$reply."')";
	$rslt=$cn->query($qry);
	if($rslt)
	{
		echo "<script> alert('Reply hasbeen done Successfully'); </script>";
	
	}



$cn->close();
?>
<br><br><a href="sidenav1.html">BACK</a>










