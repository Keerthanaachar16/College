<?php
error_reporting();
@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}

$sid=$_GET['sid'];
$fname=$_GET['fname'];
$lname=$_GET['lname'];
$email=$_GET['email'];
$phone=$_GET['phone'];
$address=$_GET['address'];
$state=$_GET['state'];
$course=$_GET['course'];
?>
<html>
<body>

<link rel="stylesheet" href="style12.css">
<form action="" method="GET">
<table border="0"  align="center" cellspacing="20">
<tr>
<td>StudentId</td>
<td><input type="text" value="<?php echo"$sid"?>"name="sid" required</td>
</tr>
<tr>
<td>Fname</td>
<td><input type="text" value="<?php echo"$fname"?>"name="fname" required</td>
</tr>
<tr>
<td>Lname</td>
<td><input type="text" value="<?php echo"$lname"?>"name="lname" required</td>
</tr>
<tr>
<td>Email</td>
<td><input type="email" value="<?php echo"$email"?>"name="email" required</td>
</tr>
<tr>
<td>Phone</td>
<td><input type="number"  min=1000000000 max=9999999999 value="<?php echo"$phone"?>"name="phone" required</td>
</tr>
<tr>
<td>Address</td>
<td><input type="text"  value="<?php echo"$address"?>"name="address" required</td >
</tr>
<tr>
<td>State</td>
<td><input type="text" value="<?php echo"$state"?>"name="state" required</td>
</tr>
<td>Course</td>
<th>
<select name="course" value="<?php echo"$course"?>"   style="width:400px;height:30px;">
	<option value="bca">BCA</option>
	<option value="bsc">B.Sc</option>
	<option value="bcom">B.com</option>
	
</select>
</td>
</tr><br>


<tr>
<td colspan="2" align="center"><input type="submit" name="submit" value="Update"></a></td></tr>
</form>
</table>
</body>
<style>
body{
	margin=0;
	padding=0;
	font-family=sans-serif;
	background-image:url("https://vectortutorials.in/wp-content/uploads/2021/06/Vector-Tutorials-Front-Page-Banner.webp");
	background-size:cover;
	background-repeat:no-repeat;
	background-attachment:fixed;
	
}
</style>
</html>
<?php
@$cn=new mysqli('localhost','root','','college');
if(mysqli_connect_errno())
{
	echo"Could not connect";
	exit;
}
if(isset($_GET['submit']))
{


	$sid=$_GET['sid'];
	$fname=$_GET['fname'];
	$lname=$_GET['lname'];
	$email=$_GET['email'];
	$phone=$_GET['phone'];
	$address=$_GET['address'];
	$state=$_GET['state'];
	$course=$_GET['course'];
	$query="update student set sid='$sid',fname='$fname',lname='$lname',email='$email',phone='$phone',address='$address',state='$state',course='$course' where sid='".$sid."'";
	$data=mysqli_query($cn,$query);
	if($data)
	{
		echo"<script>alert('record updated sucessfully')</script>";
	}
	else
	{
		echo"<script>alert('Failed to update')</script>";
	}
}

$cn->close();
?>
<br><br><a href="studentview.php">BACK</a>



